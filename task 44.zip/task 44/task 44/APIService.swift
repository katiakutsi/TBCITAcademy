//
//  APIService.swift
//  task 44
//
//  Created by katia kutsi on 6/19/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import Foundation

struct APIService{
    func getWeathers(completion: @escaping (WeathersResponse)->()) {
    
        let url = URL(string: "http://api.openweathermap.org/data/2.5/forecast?id=611717&appid=72cbd670f1189ae21eaafbb2b2359da8")!
    
        URLSession.shared.dataTask(with: url) { (data, res, err) in
        
            guard let data = data else {return}
        
            do {
                let decoder = JSONDecoder()
                let weathersResponse = try decoder.decode(WeathersResponse.self, from: data)
            
                completion(weathersResponse)
                
            } catch {print(error)}
            
        
        }.resume()
    }
}
