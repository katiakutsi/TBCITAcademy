//
//  MenuBar.swift
//  task 41
//
//  Created by katia kutsi on 6/15/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import Foundation
import UIKit

class MenuBar: UIView{
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.blue 
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
