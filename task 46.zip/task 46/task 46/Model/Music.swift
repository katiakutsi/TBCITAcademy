//
//  Music.swift
//  task 46
//
//  Created by katia kutsi on 6/22/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import Foundation
import UIKit

struct Music {
    var image: UIImage
    var title: String?
    var artist: String?
}
