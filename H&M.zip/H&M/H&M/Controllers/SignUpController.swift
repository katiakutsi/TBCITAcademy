//
//  SignUpController.swift
//  H&M
//
//  Created by katia kutsi on 7/5/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import UIKit

class SignUpController: UIViewController {
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    var newUser: User?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(try! FileManager.default.url(for: .documentationDirectory, in: .allDomainsMask, appropriateFor: nil, create: false))

    }
    
    @IBAction func backButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier, identifier == SegueIdentifier.SettingsSegue {
            if let SettingsVC = segue.destination as? SettingsController {
                //SettingsVC.signedUser = newUser
            }
        }
    }
    
    @IBAction func signUpButton(_ sender: UIButton) {
        saveUser()
        UDManager.setSigned(value: true)
        UDManager.setUser(value: newUser!.email!)
        NotificationCenter.default.post(name: NSNotification.Name("did_sign_in"), object: nil)
        performSegue(withIdentifier: SegueIdentifier.SettingsSegue, sender: nil)
    }
    
    private func saveUser(){
        let context = AppDelegate.coreDataContainer.viewContext
        let user = User(context: context)
        user.firstName = firstName.text
        user.lastName = lastName.text
        user.email = email.text
        user.password = password.text
        
        newUser = user
        do{
            try context.save()
        }catch {}
    }
    
}
