//
//  SignInController.swift
//  H&M
//
//  Created by katia kutsi on 7/5/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import UIKit
import CoreData

class SignInController: UIViewController {
    
    @IBOutlet weak var inputEmail: UITextField!
    @IBOutlet weak var inputPassword: UITextField!
    @IBOutlet weak var becomeMember: UIButton!
    
    var user: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        becomeMember.layer.borderColor = UIColor.black.cgColor
        becomeMember.layer.borderWidth = 2
    }
    
    @IBAction func signInButton(_ sender: UIButton) {
        var userExist = false
        
        for item in fetchUsers(){
            if item.email == self.inputEmail.text && item.password == self.inputPassword.text{
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let SettingsVC = storyboard.instantiateViewController(withIdentifier: "settings_page") as! SettingsController
                //SettingsVC.signedUser = item
                UDManager.setSigned(value: true)
                UDManager.setUser(value: item.email!)
                self.navigationController?.pushViewController(SettingsVC, animated: true)
                inputPassword.text = ""
                inputEmail.text = ""
                userExist = true
            NotificationCenter.default.post(name: NSNotification.Name("did_sign_in"), object: nil)

                break
            }
        }
        
        if !userExist{
            let alert = UIAlertController(title: "", message: "Email Does Not Exist or Password Is incorrect", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        inputEmail.text = ""
        inputPassword.text = ""
    }
    
    @IBAction func signUpButton(_ sender: UIButton) {
        
    }
    
    private func fetchUsers() -> [User]{
        let context = AppDelegate.coreDataContainer.viewContext
        let request: NSFetchRequest<User> = User.fetchRequest()
        
        do{
            let result = try context.fetch(request)
            let users = result as [User]
            return users
        }catch{}
        return []
    }
}
