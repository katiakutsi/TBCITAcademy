//
//  FavouritesController.swift
//  H&M
//
//  Created by katia kutsi on 7/7/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import UIKit
import CoreData

class FavouritesController: UIViewController {

    @IBOutlet weak var favouritesCollection: UICollectionView!
    
    var products = [FavouriteProduct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tabBarController?.tabBar.isHidden = false

        
        favouritesCollection.delegate = self
        favouritesCollection.dataSource = self
        
        favouritesCollection.register(UINib(nibName: OrderCell.identifier, bundle: Bundle.main), forCellWithReuseIdentifier: OrderCell.identifier)

        favouritesCollection.showsVerticalScrollIndicator = false

        products = FetchObjects.fetchFavourites(email: UDManager.getUser())
        
        

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        products.removeAll()
        products = FetchObjects.fetchFavourites(email: UDManager.getUser())
        
        favouritesCollection.reloadData()
    }
    
    private func setUpAlert() {
        
    }
    
    
}

extension FavouritesController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: favouritesCollection.frame.width, height: 177)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 30
    }
}

extension FavouritesController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = favouritesCollection.dequeueReusableCell(withReuseIdentifier: OrderCell.identifier, for: indexPath) as! OrderCell
        
        let product = products[indexPath.row]
        cell.code.text = product.code
        cell.color.text = product.color
        cell.price.text = product.price
        cell.total.text = product.price
        cell.productName.text = product.name
        cell.size.text = product.size
        product.photo?.downloadImage(completion: { (image) in
            DispatchQueue.main.async {
                cell.productImage.image = image
            }
        })
        cell.index = indexPath
        cell.delegate = self
        cell.backgroundColor = .white
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        cell.alpha = 0
        UIView.animate(withDuration: 0.5) {
            cell.alpha = 1
        }
    }
    
}
extension FavouritesController: DataCollectionProtocol {
    func deleteData(index: IndexPath) {
        self.products.remove(at: index.row)
        favouritesCollection.deleteItems(at: [index])
        favouritesCollection.reloadSections([0])

    }
}
