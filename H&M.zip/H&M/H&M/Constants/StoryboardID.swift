//
//  StoryboardID.swift
//  H&M
//
//  Created by katia kutsi on 7/10/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import Foundation

struct StoryboardID {
    public static let SettingsPage = "settings_page"
    public static let SignInPage = "sign_in_page"
}
