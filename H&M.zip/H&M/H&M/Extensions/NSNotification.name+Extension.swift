//
//  NSNotification.name+Extension.swift
//  H&M
//
//  Created by katia kutsi on 7/10/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import Foundation

extension NSNotification.Name{
    static let OrdersChannelID = NSNotification.Name("order_channel_id")
}
