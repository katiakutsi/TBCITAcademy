//
//  ProductImagesCell.swift
//  H&M
//
//  Created by katia kutsi on 7/5/20.
//  Copyright © 2020 TBC. All rights reserved.
//

import UIKit

class ProductImagesCell: UICollectionViewCell {
    
    public static let identifier = "ProductImagesCell"
    
    @IBOutlet weak var productImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
